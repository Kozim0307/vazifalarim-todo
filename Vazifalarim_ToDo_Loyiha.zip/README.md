# Vazifalarim — To-Do ilovasi

## Ishga tushirish
1. ZIP faylni oching.
2. `index.html` faylini brauzerda oching.
3. Vazifalarni qo‘shib, bajarilgan deb belgilang yoki o‘chiring.

## Xususiyatlar
- Vazifa qo‘shish, bajarilgan deb belgilash va o‘chirish
- Barchasi / Faol / Bajarilgan filtrlari
- Bajarilgan vazifalarni tozalash
- localStorage orqali ma’lumotlarni saqlash
- Telefon va kompyuter ekranlariga mos dizayn

## GitHub Pages orqali internetga joylash
1. GitHub'da yangi repository yarating.
2. `index.html`, `style.css`, `script.js` fayllarini yuklang.
3. Repository → Settings → Pages bo‘limiga kiring.
4. Deploy from a branch → `main` → `/root` ni tanlab Save bosing.
5. Sayt manzili bir ozdan keyin Pages bo‘limida chiqadi.
