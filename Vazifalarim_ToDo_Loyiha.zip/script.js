const STORAGE_KEY = "vazifalarim_todo_v1";
const form = document.getElementById("taskForm");
const input = document.getElementById("taskInput");
const list = document.getElementById("taskList");
const empty = document.getElementById("empty");
const totalEl = document.getElementById("total");
const doneEl = document.getElementById("done");
const remainingEl = document.getElementById("remaining");
const footerText = document.getElementById("footerText");
let tasks = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
let currentFilter = "all";

document.getElementById("today").textContent = new Intl.DateTimeFormat("uz-UZ", {
  weekday: "long", day: "numeric", month: "long"
}).format(new Date());

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}
function addTask(text) {
  tasks.unshift({ id: Date.now() + Math.random(), text, completed: false, createdAt: new Date().toISOString() });
  save(); render();
}
function toggleTask(id) {
  tasks = tasks.map(task => task.id === id ? {...task, completed: !task.completed} : task);
  save(); render();
}
function deleteTask(id) {
  tasks = tasks.filter(task => task.id !== id);
  save(); render();
}
function render() {
  list.innerHTML = "";
  const visible = tasks.filter(task => currentFilter === "all" ||
    (currentFilter === "active" && !task.completed) ||
    (currentFilter === "done" && task.completed));

  visible.forEach(task => {
    const li = document.createElement("li");
    li.className = "task" + (task.completed ? " completed" : "");

    const check = document.createElement("button");
    check.className = "check";
    check.type = "button";
    check.textContent = task.completed ? "✓" : "";
    check.setAttribute("aria-label", task.completed ? "Bajarilgan deb belgilangan" : "Bajarildi deb belgilash");
    check.addEventListener("click", () => toggleTask(task.id));

    const text = document.createElement("span");
    text.className = "task-text";
    text.textContent = task.text;

    const time = document.createElement("span");
    time.className = "task-time";
    time.textContent = new Intl.DateTimeFormat("uz-UZ", {hour:"2-digit", minute:"2-digit"}).format(new Date(task.createdAt));

    const remove = document.createElement("button");
    remove.className = "delete";
    remove.type = "button";
    remove.textContent = "×";
    remove.setAttribute("aria-label", "Vazifani o‘chirish");
    remove.addEventListener("click", () => deleteTask(task.id));

    li.append(check, text, time, remove);
    list.appendChild(li);
  });

  empty.classList.toggle("hidden", visible.length !== 0);
  totalEl.textContent = tasks.length;
  const completed = tasks.filter(t => t.completed).length;
  doneEl.textContent = completed;
  remainingEl.textContent = tasks.length - completed;
  footerText.textContent = tasks.length
    ? `${tasks.length} ta vazifadan ${completed} tasi bajarildi.`
    : "Barcha vazifalar bajarilishini kutmoqda.";
}
form.addEventListener("submit", event => {
  event.preventDefault();
  const value = input.value.trim();
  if (!value) return;
  addTask(value);
  input.value = "";
  input.focus();
});
document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    currentFilter = button.dataset.filter;
    document.querySelectorAll(".filter").forEach(item => item.classList.toggle("active", item === button));
    render();
  });
});
document.getElementById("clearDone").addEventListener("click", () => {
  tasks = tasks.filter(task => !task.completed);
  save(); render();
});
render();
